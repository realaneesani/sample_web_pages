<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bsoft Technologies</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="topbar">
<div id="TopSection">
<h1 id="sitename"><img src="images/bsoftNEW.png" alt="" width="158" height="41" /></h1>
<div id="topbarnav"> <span class="topnavitems">| <a href="#">Register</a> | <a href="#">Login </a></span><form action="#"><div class="searchform">
  <label for="searchtxt">
    Search Terms:
  </label>
  <input class="keywordfield" id="searchtxt"/>
  <input type="submit" value="Search" />
</div> </form></div>
<div class="clear"></div>
<div id="nav">
<ul id="topmenu" class="sf-menu dropdown">
<li class="selected"><a href="index.html">Home</a></li>
            <li><a class="has_submenu" href="about.html">About</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">Full IT Solutions</font></a></li>
                    <li><a href="#"><font color="#FF3366">Software Supporting</font></a></li>
                </ul>
      </li>

            <li><a href="services.html">Services</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">Motherboard</font></a></li>
                    <li><a href="#"><font color="#FF3366">Projector</font></a></li>
                    <li><a href="#"><font color="#FF3366">Laptop</font></a></li>
                    <li><a href="#"><font color="#FF3366">LCD Monitor</font></a></li>
                    <li><a href="#"><font color="#FF3366">TV</font></a></li>
                    <li><a href="#"><font color="#FF3366">Audio Devices</font></a></li>
                    <li><a href="#"><font color="#FF3366">SMPS</font></a></li>
                    <li><a href="#"><font color="#FF3366">Electronic Devices</font></a></li>
                </ul>
      </li>
           <li><a href="rent.html">Rental Items</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">Projector</font></a></li>
                    <li><a href="#"><font color="#FF3366">Laptop</font></a></li>
                    <li><a href="#"><font color="#FF3366">Desktop</font></a></li>
                    <li><a href="#"><font color="#FF3366">LCD Monitor</font></a></li>
                    <li><a href="#"><font color="#FF3366">UPS and Inverter</font></a></li>
                </ul>
      </li>

           <li><a href="contract.php">Contract</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">IT Product</font></a></li>
                    <li><a href="#"><font color="#FF3366">Motherboard</font></a></li>
                    <li><a href="#"><font color="#FF3366">Laptop</font></a></li>
                    <li><a href="#"><font color="#FF3366">Projector</font></a></li>
                    <li><a href="#"><font color="#FF3366">Electronic Devices</font></a></li>
                </ul>
      </li>
      
           <li><a href="client.php">Clients</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">IT Dealers</font></a></li>
                    <li><a href="#"><font color="#FF3366">Co-Operative Firms</font></a></li>
                    <li><a href="#"><font color="#FF3366">Defence</font></a></li>
                    <li><a href="#"><font color="#FF3366">Naval Engineering</font></a></li>
                    <li><a href="#"><font color="#FF3366">Asianet</font></a></li>
                    <li><a href="#"><font color="#FF3366">All Private Firms</font></a></li>

                </ul>
      </li>

           <li><a href="contact.html">Contact</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">BSOFT TECHNOLOGIES</font></a></li>
                    <li><a href="#"><font color="#FF3366">LIG 328</font></a></li>
                    <li><a href="#"><font color="#FF3366">GandhiNagar</font></a></li>
                    <li><a href="#"><font color="#FF3366">Kadavanthra</font></a></li>
                    <li><a href="#"><font color="#FF3366">Cochin -20</font></a></li>
                                        <li><a href="#"><font color="#FF3366">Res.: 0484- 3000780</font></a></li>
                    <li><a href="#"><font color="#FF3366">Mob: 8129664780</font></a></li>
               </ul>
      </li>

</ul>
</div>
</div>
</div>

<div id="wrap">
<div id="headershort">
<h2 class="subheader">&nbsp;</h2>
</div>
<div id="contents">
<div id="left">
<h2><font color="#993333">Our Clients.......</font></h2>
<p> 