<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bsoft Technologies</title>
<link rel="stylesheet" type="text/css" href="tcal.css" />
	<script type="text/javascript" src="tcal.js"></script> 
<link href="style.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="jquery-1.4.1.min.js"></script>
	<script type="text/javascript" src="slideshow.js"></script>
		<link rel="stylesheet" href="main.css" type="text/css" />
       </head>
<body>
<div id="topbar">
<div id="TopSection">
<h1 id="sitename"><span><a href="#"><img src="images/bsoftNEW.png" alt="" width="158" height="41" /></a></h1>
<div id="topbarnav"> <span class="topnavitems"><a href="#">Register</a> | <a href="#">Login </a></span><form action="#"><div class="searchform">
  <label for="searchtxt">
    Search Terms:
  </label>
  <input class="keywordfield" id="searchtxt" required/>
  <input type="submit" value="Search" />
</div> </form></div>
<div class="clear"></div>
<div id="nav">
<ul id="topmenu" class="sf-menu dropdown">
<li class="selected"><a href="index.html">Home</a></li>
            <li><a class="has_submenu" href="about.html">About</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">Full IT Solutions</font></a></li>
                    <li><a href="#"><font color="#FF3366">Software Supporting</font></a></li>
                </ul>
      </li>

            <li><a href="services.html">Services</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">Motherboard</font></a></li>
                    <li><a href="#"><font color="#FF3366">Projector</font></a></li>
                    <li><a href="#"><font color="#FF3366">Laptop</font></a></li>
                    <li><a href="#"><font color="#FF3366">LCD Monitor</font></a></li>
                    <li><a href="#"><font color="#FF3366">TV</font></a></li>
                    <li><a href="#"><font color="#FF3366">Audio Devices</font></a></li>
                    <li><a href="#"><font color="#FF3366">SMPS</font></a></li>
                    <li><a href="#"><font color="#FF3366">Electronic Devices</font></a></li>
                </ul>
      </li>
           <li><a href="rent.html">Rental Items</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">Projector</font></a></li>
                    <li><a href="#"><font color="#FF3366">Laptop</font></a></li>
                    <li><a href="#"><font color="#FF3366">Desktop</font></a></li>
                    <li><a href="#"><font color="#FF3366">LCD Monitor</font></a></li>
                    <li><a href="#"><font color="#FF3366">UPS and Inverter</font></a></li>
                </ul>
      </li>

           <li><a href="contract.php">Contract</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">IT Product</font></a></li>
                    <li><a href="#"><font color="#FF3366">Motherboard</font></a></li>
                    <li><a href="#"><font color="#FF3366">Laptop</font></a></li>
                    <li><a href="#"><font color="#FF3366">Projector</font></a></li>
                    <li><a href="#"><font color="#FF3366">Electronic Devices</font></a></li>
                </ul>
      </li>
      
           <li><a href="client.php">Clients</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">IT Dealers</font></a></li>
                    <li><a href="#"><font color="#FF3366">Co-Operative Firms</font></a></li>
                    <li><a href="#"><font color="#FF3366">Defence</font></a></li>
                    <li><a href="#"><font color="#FF3366">Naval Engineering</font></a></li>
                    <li><a href="#"><font color="#FF3366">Asianet</font></a></li>
                    <li><a href="#"><font color="#FF3366">All Private Firms</font></a></li>

                </ul>
      </li>

           <li><a href="contact.html">Contact</a>
            	<ul>
                	<li><a href="#"><font color="#FF3366">BSOFT TECHNOLOGIES</font></a></li>
                    <li><a href="#"><font color="#FF3366">LIG 328</font></a></li>
                    <li><a href="#"><font color="#FF3366">GandhiNagar</font></a></li>
                    <li><a href="#"><font color="#FF3366">Kadavanthra</font></a></li>
                    <li><a href="#"><font color="#FF3366">Cochin -20</font></a></li>
                                        <li><a href="#"><font color="#FF3366">Office: 0484- 3000780</font></a></li>
                    <li><a href="#"><font color="#FF3366">Mob: 8129664780</font></a></li>
               </ul>
      </li>

</ul>
</div>
</div>
</div>

<div id="wrap">
<div id="header3">
<h2 class="introtext">&nbsp;</h2>
</div>
<div id="contents">
<div class="clear"></div>
<div id="aboutdiv">
<div id="pitch">
  <p>&nbsp;</p>
  <p>B Soft Technology Provide Annual Contract or short time contract for all the components..........!</p>
  <div id="slideshow">
    
<div class="active"><img src="images/contract/1.jpg" alt="" width="" /></div>
<div><img src="images/contract/5.jpg" alt="" width="" /></div>
<div><img src="images/contract/2.jpg" alt="" /></div>
<div><img src="images/contract/3.jpg" alt="" /></div>
<div><img src="images/contract/4.jpg" alt="" /></div>
<div><img src="images/contract/6.jpg" alt="" /></div>
<div><img src="images/contract/7.jpg" alt="" /></div>
<div><img src="images/contract/8.jpg" alt="" /></div>
<div><img src="images/contract/9.jpg" alt="" /></div>
<div><img src="images/contract/10.jpg" alt="" /></div>
<div><img src="images/contract/11.jpg" alt="" /></div>
<div><img src="images/contract/13.jpg" alt="" /></div>
<div><img src="images/contract/12.jpg" alt="" /></div>
<div><img src="images/contract/15.jpg" alt="" /></div>
<div><img src="images/contract/download (4).jpg" alt="" /></div>
<div><img src="images/contract/14.jpg" alt="" /></div>
				<div>	<img src="images/contract/1.jpg" alt="" width="" /></div>

  </div>
</div>
</div>
<div id="homecontents"> 
  <h2><font color="#993333">Contract Forum......</font></h2>
  <p>&nbsp;&nbsp;</p>
  